# -*- coding: utf-8 -*-
"""
metrics.py — Módulo de autoevaluación para NeuraBoardEco
Registra recompensas de cada ciclo, calcula promedios móviles
y detecta si el sistema está aprendiendo o estancado.
"""

import json
import time
from pathlib import Path
from statistics import mean

BASE_PATH = Path.home() / "NeuraBoardEco"
MEM_PATH = BASE_PATH / "memory.json"
LOG_PATH = BASE_PATH / "logs" / "metrics.log"


class LearningMetrics:
    def __init__(self):
        self.history = []
        self._load()

    def _load(self):
        """Carga métricas previas desde memory.json"""
        if MEM_PATH.exists():
            try:
                data = json.loads(MEM_PATH.read_text(encoding="utf-8"))
                self.history = data.get("metrics_history", [])
            except Exception:
                self.history = []

    def _save(self):
        """Guarda métricas actualizadas en memoria.json y en metrics.log"""
        if not BASE_PATH.exists():
            BASE_PATH.mkdir(parents=True, exist_ok=True)

        data = {}
        if MEM_PATH.exists():
            try:
                data = json.loads(MEM_PATH.read_text(encoding="utf-8"))
            except Exception:
                data = {}

        data["metrics_history"] = self.history
        MEM_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        # Registrar también en el log plano
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"[{time.ctime()}] Última recompensa: {self.history[-1]['reward']}\n")

    def register_cycle(self, reward: float):
        """Registra una nueva recompensa"""
        entry = {"timestamp": time.time(), "reward": reward}
        self.history.append(entry)
        if len(self.history) > 100:
            self.history = self.history[-100:]  # mantener últimas 100 entradas
        self._save()

    def get_trend(self):
        """Analiza la tendencia del aprendizaje"""
        if len(self.history) < 5:
            return "📊 Aún pocos datos para detectar tendencia"
        rewards = [r["reward"] for r in self.history]
        avg_recent = mean(rewards[-5:])
        avg_total = mean(rewards)
        if avg_recent > avg_total:
            return "📈 Aprendizaje positivo"
        elif avg_recent < avg_total:
            return "📉 Rendimiento descendente"
        else:
            return "⚖️ Estable"

    def summary(self):
        """Resumen rápido"""
        if not self.history:
            return "Sin datos de entrenamiento aún."
        avg = mean([r["reward"] for r in self.history])
        trend = self.get_trend()
        return f"📘 Ciclos: {len(self.history)} | Promedio: {avg:.2f} | {trend}"
