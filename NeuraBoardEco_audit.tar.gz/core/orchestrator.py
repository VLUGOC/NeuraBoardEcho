# -*- coding: utf-8 -*-
"""
NeuraBoardEco - Núcleo de Orquestación
Control base del sistema y activación de agentes.
"""

import time, json
from pathlib import Path
from rich import print
from eco_ant.pheromones import PheromoneTable

MEM_PATH = Path.home() / "NeuraBoardEco" / "memory.json"

def init_memory():
    if not MEM_PATH.exists():
        MEM_PATH.write_text(json.dumps({"logs": []}, indent=2))

def log(message: str):
    data = json.loads(MEM_PATH.read_text())
    data["logs"].append({"msg": message, "ts": time.time()})
    MEM_PATH.write_text(json.dumps(data, indent=2))
    print(f"[NeuraBoard] {message}")

def start_system():
    log("🧠 Iniciando núcleo NeuraBoardEco...")
    time.sleep(0.5)
    log("⚙️ Cargando módulos principales...")
    time.sleep(0.5)
    log("✅ Sistema operativo y estable.")

if __name__ == "__main__":
    init_memory()
    start_system()

    try:
        ant = PheromoneTable(persist_in_memory=True)
        state = "idle"
        actions = ["backup", "analyze_market", "optimize_cpu"]
        choice = ant.choose_action(state, actions, {"optimize_cpu": 1.1, "backup": 0.9})
        reward = 5.0 if choice == "optimize_cpu" else 2.0
        ant.deposit([(state, choice)], reward)
        log(f"🐜 Ant-Colony RL ejecutó acción: {choice} con recompensa {reward}")
    except Exception as e:
        log(f"Ant-RL skip: {e}")

# Registro de métricas automáticas
from metrics import LearningMetrics

metrics = LearningMetrics()
metrics.register_cycle(5.0)  # reemplaza con tu valor real de recompensa
print(metrics.summary())
